import React from "react";
import Components from "./components.css";

const recheck = () => {
  return (
    <div className="card">
      <lottie-player
        src="https://lottie.host/d02c13d1-64f4-4b25-be96-f9011d233b0c/hGNL8v8peX.json"
        background="#FFFFFF"
        speed="1"
        loop
        autoplay
        direction="1"
        mode="normal"></lottie-player>
    </div>
  );
};

export default recheck;
