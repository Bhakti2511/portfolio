import React, { useEffect, useState } from "react";
import component from "./components.css";
import Form from "./forms.js";
import Recheck from "./recheck.js";

const Components = () => {
  return (
    <>
      <section id="container">
        <div className="container">
          <div className="heading">
            <h2>To Do List</h2>
          </div>

          <div className="main">
            <div className="block1">
              <Form />
            </div>
            <div className="block1">
                <Recheck />
            </div>
          </div>
        </div>
      </section>
    </>
  );
};

export default Components;
