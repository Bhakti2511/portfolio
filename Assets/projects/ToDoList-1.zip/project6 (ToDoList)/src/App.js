import logo from "./logo.svg";
import "./App.css";
import Components from "./Components/components.js";

function App() {
  return (
    <div className="App">
      <Components />
    </div>
  );
}

export default App;
