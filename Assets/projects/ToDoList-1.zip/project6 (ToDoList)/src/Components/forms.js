import React, { useState } from "react";


const Forms = () => {
  const [inputlist, setinputlist] = useState("");
  const [Items, setItems] = useState([]);

  const itemEvent = (e) => {
    setinputlist(e.target.value);
  };

  const deleteitem=(e)=>{
    console.log("delete item" + e);

    setItems((oldItem)=>{
      return oldItem.filter((arrElm,index)=>{
        return index!==e;
      })
    })
  }

  const listItem = () => {
    setItems((oldItem) => {
      return [...oldItem, inputlist];
    });
    setinputlist('');
  };
  return (
    <div className="card">
      <center>
        <div className="header-card">New Entry</div>
      </center>
      <div className="lbl">
        <input
          type="text"
          placeholder="Add Item"
          value={inputlist}
          onChange={itemEvent}
        />
        <button onClick={listItem}> + </button>
        <br />

        <ul>
          {Items.map((itemval, index) => {
            return (
              <>
                <div className="img-txt">
                  <img
                    width="20"
                    height="20"
                    src="https://img.icons8.com/material-outlined/24/000000/filled-trash.png"
                    alt="filled-trash"
                    onClick={(e) => deleteitem(index)}
                  />
                  <li key={index} id={index} value={itemval}>
                    {itemval}
                  </li>
                </div>
              </>
            );
          })}
        </ul>
      </div>
    </div>
  );
};

export default Forms;
